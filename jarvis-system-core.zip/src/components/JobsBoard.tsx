import React, { useState } from "react";
import { ScreenId, JobCard, JobColumn } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { Briefcase, ArrowUpRight, MessageSquare, ShieldCheck, RefreshCw, FileText, Download, X, CheckCircle2, AlertCircle } from "lucide-react";

interface JobsBoardProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
}

export default function JobsBoard({ activeScreen, onNavigate }: JobsBoardProps) {
  const [columns, setColumns] = useState<JobColumn[]>([
    {
      id: "col-interested",
      title: "INTERESTED",
      count: "03",
      accentClass: "text-[#8aebff] border-[#8aebff]/20 bg-[#8aebff]/5",
      cards: [
        {
          id: "job-1",
          title: "Lead AI Engineer",
          company: "Neuralink",
          location: "San Francisco, CA",
          atsScore: 94,
          remote: true,
        },
        {
          id: "job-2",
          title: "Senior UX Designer",
          company: "OpenAI",
          location: "London, UK",
          atsScore: 88,
        },
      ],
    },
    {
      id: "col-applied",
      title: "APPLIED",
      count: "04",
      accentClass: "text-[#8aebff] border-[#8aebff]/20 bg-[#8aebff]/5",
      cards: [
        {
          id: "job-3",
          title: "Interface Scientist",
          company: "SpaceX",
          location: "Hawthorne, CA",
          atsScore: 91,
        },
      ],
    },
    {
      id: "col-interviewing",
      title: "INTERVIEWING",
      count: "02",
      accentClass: "text-[#8aebff] border-[#8aebff]/40 bg-[#8aebff]/10",
      cards: [
        {
          id: "job-4",
          title: "Head of Systems",
          company: "Anthropic",
          location: "Palo Alto, CA",
          atsScore: 97,
          round: "Round 3",
        },
      ],
    },
    {
      id: "col-offer",
      title: "OFFER",
      count: "01",
      accentClass: "text-[#ffd6a3] border-[#ffd6a3]/40 bg-[#ffd6a3]/10",
      cards: [
        {
          id: "job-5",
          title: "Systems Architect",
          company: "Tesla Bot",
          location: "Austin, TX",
          atsScore: 99,
          actionRequired: true,
        },
      ],
    },
    {
      id: "col-accepted",
      title: "ACCEPTED",
      count: "01",
      accentClass: "text-[#bbc9cd] border-white/10 bg-white/5",
      opacityClass: "opacity-60",
      cards: [
        {
          id: "job-6",
          title: "Data Lead",
          company: "Palantir",
          location: "Denver, CO",
          atsScore: 95,
          isClosed: true,
        },
      ],
    },
    {
      id: "col-rejected",
      title: "REJECTED",
      count: "01",
      accentClass: "text-[#ffb4ab] border-[#ffb4ab]/20 bg-[#ffb4ab]/5",
      opacityClass: "opacity-40",
      grayscale: true,
      cards: [
        {
          id: "job-7",
          title: "Research Intern",
          company: "Boston Dynamics",
          location: "Waltham, MA",
          atsScore: 68,
        },
      ],
    },
  ]);

  const [activeTab, setActiveTab] = useState<"keyword" | "star">("keyword");

  // Handle card click (lead AI engineer card should open modal)
  const handleCardClick = (card: JobCard) => {
    if (card.title === "Lead AI Engineer") {
      onNavigate(ScreenId.AtsAnalysis);
    }
  };

  const closeModal = () => {
    onNavigate(ScreenId.Jobs);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
      className="space-y-6"
    >
      {/* Toolbar / Section title */}
      <section className="pt-4 max-w-full mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#dfe2f3] flex items-center gap-4 font-mono">
              <span className="opacity-40 font-light text-xl">01 //</span> APPLICATIONS
              <span className="text-sm font-semibold bg-[#8aebff]/10 text-[#8aebff] px-3.5 py-1 rounded-full border border-[#8aebff]/20">
                12 ACTIVE
              </span>
            </h1>
            <p className="text-xs font-mono text-[#859397] uppercase tracking-widest mt-1 opacity-80">
              Neural Career Node Synchronization: Complete
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono">
            <button className="flex items-center gap-2 px-5 py-2 bg-white/5 border border-white/10 rounded-lg text-xs font-semibold hover:bg-white/10 hover:border-[#8aebff]/30 transition-all text-[#8aebff] cursor-pointer">
              <FileText className="w-4 h-4" />
              SYNC RÉSUMÉ
            </button>
            <button className="flex items-center justify-center w-10 h-10 bg-white/5 border border-white/10 rounded-lg text-[#859397] hover:text-[#8aebff] transition-all cursor-pointer">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Kanban Board Layout */}
      <section className="overflow-x-auto pb-6 scrollbar-hide">
        <div className="flex gap-6 min-w-[1200px] px-2">
          {columns.map((col) => (
            <div
              key={col.id}
              className={`flex-shrink-0 w-80 glass-column flex flex-col rounded-xl min-h-[500px] ${
                col.opacityClass || ""
              } ${col.grayscale ? "grayscale" : ""}`}
            >
              {/* Column Header */}
              <div className="p-4 border-b border-white/5 flex justify-between items-center bg-white/5">
                <span className="text-xs font-bold font-mono text-[#859397] tracking-widest">
                  {col.title}
                </span>
                <span className={`text-xs font-mono px-2.5 py-0.5 rounded border ${col.accentClass}`}>
                  {col.count}
                </span>
              </div>

              {/* Column Cards Container */}
              <div className="p-4 space-y-4 flex-1">
                {col.cards.map((card) => {
                  const isLeadAI = card.title === "Lead AI Engineer";
                  return (
                    <div
                      key={card.id}
                      onClick={() => handleCardClick(card)}
                      className={`glass-card p-5 rounded-xl cursor-pointer group relative overflow-hidden ${
                        isLeadAI ? "border-[#8aebff]/40 shadow-lg hover:border-[#8aebff]" : ""
                      }`}
                    >
                      {/* Interactive Cyan left border indicator for highlighted cards */}
                      {card.round && (
                        <div className="absolute left-0 top-0 w-1 h-full bg-[#8aebff] shadow-[0_0_15px_#8aebff]"></div>
                      )}

                      <div className="flex justify-between items-start mb-2">
                        {/* Heading strictly nested inside a glass-card for Lead AI Engineer xpath */}
                        <h3 className="text-base font-bold text-[#dfe2f3] group-hover:text-[#8aebff] transition-colors leading-snug">
                          {card.title}
                        </h3>
                        {card.round ? (
                          <MessageSquare className="w-4 h-4 text-[#8aebff] group-hover:scale-110 transition-transform" />
                        ) : card.actionRequired ? (
                          <ShieldCheck className="w-4 h-4 text-[#ffd6a3] group-hover:scale-110 transition-transform" />
                        ) : (
                          <ArrowUpRight className="w-4 h-4 text-[#8aebff]/40 group-hover:text-[#8aebff] group-hover:translate-x-0.5 transition-all" />
                        )}
                      </div>

                      <p className="text-xs font-mono text-[#859397] mb-4">
                        {card.company} • {card.location}
                      </p>

                      <div className="flex items-center gap-2">
                        <span
                          className={`ats-chip px-2.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                            card.atsScore >= 95 ? "text-[#ffd6a3] border-[#ffd6a3]/30" : "text-[#8aebff]"
                          }`}
                        >
                          ATS: {card.atsScore}%
                        </span>

                        {card.remote && (
                          <span className="text-[10px] font-bold font-mono text-[#859397] px-2.5 py-0.5 bg-white/5 rounded border border-white/5 uppercase">
                            Remote
                          </span>
                        )}

                        {card.round && (
                          <span className="text-[10px] font-bold font-mono text-[#8aebff] px-2.5 py-0.5 bg-[#8aebff]/10 rounded border border-[#8aebff]/20 animate-pulse uppercase">
                            {card.round}
                          </span>
                        )}

                        {card.actionRequired && (
                          <span className="text-[10px] font-bold font-mono text-[#ffd6a3] px-2.5 py-0.5 bg-[#ffd6a3]/10 rounded border border-[#ffd6a3]/20 uppercase">
                            Action Required
                          </span>
                        )}

                        {card.isClosed && (
                          <span className="text-[10px] font-bold font-mono text-[#859397] uppercase tracking-wider">
                            Closed
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Slide-Up ATS Analysis Modal Overlay */}
      <AnimatePresence>
        {activeScreen === ScreenId.AtsAnalysis && (
          <div className="fixed inset-0 bg-[#0a0e1a]/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 180 }}
              className="w-full max-w-3xl glass-panel rounded-2xl overflow-hidden shadow-2xl border border-[#8aebff]/20"
            >
              {/* Modal header */}
              <div className="p-6 border-b border-[#3c494c]/50 bg-[#161e2e]/80 flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-extrabold text-[#dfe2f3] tracking-wide uppercase font-mono">
                    ATS Alignment Analysis
                  </h2>
                  <div className="flex items-center gap-3 mt-1 text-xs">
                    <span className="text-[#859397] font-mono">TARGET:</span>
                    <span className="text-[#dfe2f3] font-semibold">Lead AI Engineer</span>
                    <span className="px-2 py-0.5 bg-[#8aebff]/10 rounded text-[10px] font-mono text-[#8aebff] border border-[#8aebff]/20">
                      NEURALINK
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right font-mono hidden sm:block">
                    <span className="text-[9px] text-[#859397] block">ANALYSIS_ID</span>
                    <span className="text-[11px] text-[#8aebff] font-semibold">X-99-ALPHA-HUD</span>
                  </div>
                  {/* Close button with aria-label close modal */}
                  <button
                    onClick={closeModal}
                    aria-label="Close modal"
                    className="p-2 hover:bg-white/5 text-[#bbc9cd] hover:text-[#8aebff] transition-all rounded-full border border-white/5 cursor-pointer flex items-center justify-center"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Modal Core Content */}
              <div className="p-6 space-y-6">
                {/* Large circular match gauge */}
                <div className="flex flex-col items-center py-6 border-b border-white/5">
                  <div className="relative w-44 h-44 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90">
                      <circle
                        className="text-[#8aebff]/10"
                        cx="88"
                        cy="88"
                        fill="transparent"
                        r="76"
                        stroke="currentColor"
                        strokeWidth="3"
                      ></circle>
                      <circle
                        className="text-[#8aebff] glow-cyan"
                        cx="88"
                        cy="88"
                        fill="transparent"
                        r="76"
                        stroke="currentColor"
                        strokeDasharray="477"
                        strokeDashoffset="71.5" // ~85%
                        strokeLinecap="butt"
                        strokeWidth="6"
                      ></circle>
                    </svg>
                    <div className="absolute flex flex-col items-center">
                      <span className="text-4xl font-extrabold text-[#dfe2f3] font-mono glow-cyan leading-none">
                        85
                      </span>
                      <span className="text-[10px] font-mono text-[#859397] uppercase tracking-widest mt-1">
                        MATCH SCORE
                      </span>
                    </div>
                  </div>
                </div>

                {/* Tab buttons */}
                <div className="flex border-b border-[#3c494c]/40 font-mono text-xs">
                  <button
                    onClick={() => setActiveTab("keyword")}
                    className={`px-6 py-2.5 border-b-2 font-semibold transition-all cursor-pointer ${
                      activeTab === "keyword"
                        ? "border-[#8aebff] text-[#8aebff]"
                        : "border-transparent text-[#859397] hover:text-[#dfe2f3]"
                    }`}
                  >
                    KEYWORD MATRIX
                  </button>
                  <button
                    onClick={() => setActiveTab("star")}
                    className={`px-6 py-2.5 border-b-2 font-semibold transition-all cursor-pointer ${
                      activeTab === "star"
                        ? "border-[#8aebff] text-[#8aebff]"
                        : "border-transparent text-[#859397] hover:text-[#dfe2f3]"
                    }`}
                  >
                    STAR/XYZ PLAN
                  </button>
                </div>

                {/* Table/List of core competency vs status */}
                {activeTab === "keyword" ? (
                  <div className="space-y-4 font-mono text-xs">
                    <div className="flex items-center justify-between text-[#859397] uppercase tracking-wider border-b border-white/5 pb-2">
                      <span>CORE COMPETENCY</span>
                      <span>STATUS</span>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between py-1 border-b border-white/5">
                        <span className="text-[#dfe2f3]">Large Language Models (LLM)</span>
                        <div className="flex items-center gap-1.5 text-[#8aebff]">
                          <CheckCircle2 className="w-4 h-4" />
                          <span className="font-semibold">Present</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 border-b border-white/5">
                        <span className="text-[#dfe2f3]">Neural Interfacing Tech</span>
                        <div className="flex items-center gap-1.5 text-[#8aebff]">
                          <CheckCircle2 className="w-4 h-4" />
                          <span className="font-semibold">Present</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 border-b border-white/5">
                        <span className="text-[#dfe2f3]">Distributed Systems</span>
                        <div className="flex items-center gap-1.5 text-[#ffd6a3]">
                          <AlertCircle className="w-4 h-4" />
                          <span className="font-semibold">Missing</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 border-b border-white/5">
                        <span className="text-[#dfe2f3]">PyTorch / TensorFlow</span>
                        <div className="flex items-center gap-1.5 text-[#8aebff]">
                          <CheckCircle2 className="w-4 h-4" />
                          <span className="font-semibold">Present</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between py-1 border-b border-white/5">
                        <span className="text-[#dfe2f3]">Bio-Signal Processing</span>
                        <div className="flex items-center gap-1.5 text-[#ffd6a3]">
                          <AlertCircle className="w-4 h-4" />
                          <span className="font-semibold">Missing</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 font-mono text-xs text-[#bbc9cd] leading-relaxed p-4 bg-white/5 rounded-lg border border-white/5">
                    <p className="font-semibold text-[#8aebff] mb-2 uppercase tracking-wide">
                      Optimized Bullet suggestions for STAR criteria:
                    </p>
                    <p>
                      • Directed development of high-throughput distributed tensor pipelines, achieving a 34% reduction in neural handshake latencies.
                    </p>
                    <p>
                      • Spearheaded structural integration of real-time multi-electrode telemetry systems using PyTorch on Kubernetes infrastructure.
                    </p>
                  </div>
                )}
              </div>

              {/* Modal footer download action */}
              <div className="p-6 bg-white/5 border-t border-white/5">
                <button
                  onClick={() => alert("Resume Optimization file downloaded.")}
                  className="w-full bg-[#22d3ee] hover:bg-[#8aebff] text-[#00363e] py-3 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg hover:scale-[1.01]"
                >
                  <Download className="w-4.5 h-4.5" />
                  DOWNLOAD OPTIMIZED TEXT FILE
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
