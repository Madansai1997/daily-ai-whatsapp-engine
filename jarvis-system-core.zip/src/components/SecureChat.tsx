import React, { useState, useRef, useEffect } from "react";
import { ChatMessage } from "../types";
import { motion } from "motion/react";
import { Plus, Mic, Send, Volume2, ShieldAlert } from "lucide-react";

export default function SecureChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "msg-1",
      sender: "JARVIS",
      time: "10:42 AM",
      content: "Neural pathways synchronized. I have updated the encryption keys for the current session. I'm standing by to assist with your deep-analysis request on the Aetheris core module."
    },
    {
      id: "msg-2",
      sender: "User_Admin",
      time: "10:43 AM",
      content: "Initiate diagnostic sweep of the localized memory banks. I suspect a latency leak in the primary tensor cluster."
    },
    {
      id: "msg-3",
      sender: "JARVIS",
      time: "10:44 AM",
      content: "Diagnostics initiated. Scanning tensor cluster B-12... Found 3.2ms deviation in float32 operations.",
      codeBlock: {
        title: "Live Data Output",
        lines: [
          "[STATUS] Scanning Tensor Core...",
          "[WARN] Memory Leak detected in @cluster-B12",
          "[INFO] Attempting re-allocation..."
        ]
      }
    }
  ]);

  const [inputVal, setInputVal] = useState("");
  const [isPrivaChatMode, setIsPrivaChatMode] = useState(true);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!inputVal.trim()) return;

    const userTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    const userMsg: ChatMessage = {
      id: `msg-user-${Date.now()}`,
      sender: "User_Admin",
      time: userTime,
      content: inputVal
    };

    setMessages((prev) => [...prev, userMsg]);
    const commandText = inputVal.trim();
    setInputVal("");

    // Simulate JARVIS response
    setTimeout(() => {
      const jarvisTime = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      let replyContent = `Protocol "${commandText}" registered. Analyzing structural arrays... all clear.`;
      let codeBlockData;

      const lower = commandText.toLowerCase();
      if (lower.includes("status") || lower.includes("diagnostic")) {
        replyContent = "Initiating comprehensive audit of secondary sectors. System integrity remains at 98.4%.";
        codeBlockData = {
          title: "Diagnostic Output",
          lines: [
            "[OK] Database sync stable",
            "[OK] Port routing verified",
            "[OK] AES-256 session authenticated"
          ]
        };
      } else if (lower.includes("clear")) {
        setMessages([
          {
            id: `msg-clear-${Date.now()}`,
            sender: "JARVIS",
            time: jarvisTime,
            content: "Terminal buffer flushed. Encrypted session continues uninterrupted."
          }
        ]);
        return;
      } else if (lower.includes("help") || lower.includes("protocols")) {
        replyContent = "Supported voice and query syntax options available: 'status', 'diagnostic', 'clear', or custom natural language analysis requests.";
      }

      const jarvisMsg: ChatMessage = {
        id: `msg-jarvis-${Date.now()}`,
        sender: "JARVIS",
        time: jarvisTime,
        content: replyContent,
        codeBlock: codeBlockData
      };

      setMessages((prev) => [...prev, jarvisMsg]);
    }, 1000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col h-[calc(100vh-140px)]"
    >
      {/* Encryption Status indicator */}
      <div className="mt-2 mb-4 flex flex-col gap-1">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-[#8aebff] shadow-[0_0_10px_#8aebff]"></div>
          <h3 className="text-[#8aebff] font-bold text-xs tracking-[0.2em] uppercase font-mono">
            Encryption Status
          </h3>
        </div>
        <p className="text-[10px] font-mono text-[#8aebff]/60 tracking-widest uppercase ml-5">
          Level 7 Secure Channel // Active
        </p>
      </div>

      {/* Main chat interface */}
      <section className="flex-1 glass-panel rounded-2xl flex flex-col overflow-hidden">
        {/* Chat window header */}
        <div className="px-6 py-4 border-b border-[#8aebff]/10 bg-[#1b1f2c]/30 flex justify-between items-center">
          <div>
            <h2 className="text-lg font-bold text-[#dfe2f3] flex items-center gap-3 tracking-wide">
              Secure Session
              <span className="px-2 py-0.5 bg-[#8aebff]/10 rounded text-[9px] font-mono text-[#8aebff] border border-[#8aebff]/20 tracking-widest font-semibold">
                #8821-X
              </span>
            </h2>
            <p className="text-[11px] font-mono text-[#8aebff]/60 flex items-center gap-2 mt-1 uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8aebff] animate-pulse"></span>
              End-to-end encrypted protocol engaged.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-[#8aebff]/5 rounded-full px-4 py-1.5 border border-[#8aebff]/20">
            <span className="text-[10px] font-mono text-[#8aebff] tracking-widest uppercase font-semibold">
              PrivaChat Mode
            </span>
            <div
              className={`w-10 h-5 rounded-full relative cursor-pointer transition-colors duration-200 ${
                isPrivaChatMode ? "bg-[#8aebff]/30" : "bg-[#3c494c]/50"
              }`}
              onClick={() => setIsPrivaChatMode(!isPrivaChatMode)}
            >
              <div
                className={`absolute top-0.5 w-4 h-4 rounded-full transition-transform duration-200 bg-[#8aebff] shadow-[0_0_8px_rgba(138,235,255,0.6)] ${
                  isPrivaChatMode ? "right-0.5" : "left-0.5 translate-x-0"
                }`}
              ></div>
            </div>
          </div>
        </div>

        {/* Chat message logs scrollbox */}
        <div className="flex-1 overflow-y-auto px-6 py-8 space-y-8 custom-scrollbar">
          {messages.map((msg) => {
            const isJarvis = msg.sender === "JARVIS";
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isJarvis ? "items-start max-w-2xl" : "items-end"}`}
              >
                {/* Message Meta Info */}
                <div className="flex items-center gap-2 mb-1 px-1">
                  {isJarvis && <div className="w-1.5 h-1.5 rounded-full bg-[#8aebff]"></div>}
                  <span
                    className={`text-[10px] font-mono tracking-widest uppercase font-bold ${
                      isJarvis ? "text-[#8aebff]" : "text-[#dfe2f3]"
                    }`}
                  >
                    {msg.sender === "JARVIS" ? "JARVIS" : "User_Admin"}
                  </span>
                  <span className="text-[9px] font-mono text-[#8aebff]/30">{msg.time}</span>
                  {!isJarvis && (
                    <div className="w-1.5 h-1.5 rounded-full border border-[#8aebff]/50"></div>
                  )}
                </div>

                {/* Message Balloon */}
                <div
                  className={`p-5 rounded-xl backdrop-blur-md relative overflow-hidden text-sm leading-relaxed ${
                    isJarvis
                      ? "hologram-bubble rounded-tl-none border-l-2 border-l-[#8aebff]"
                      : "user-bubble rounded-tr-none text-right text-[#8aebff]/90 max-w-xl"
                  }`}
                >
                  <p>{msg.content}</p>

                  {/* Diagnostic details box for JARVIS */}
                  {isJarvis && msg.codeBlock && (
                    <div className="bg-[#0a0e1a]/60 p-4 rounded-lg border border-[#8aebff]/20 font-mono text-xs text-[#8aebff]/80 mt-4 backdrop-blur-sm">
                      <div className="flex items-center gap-2 mb-2 text-[#8aebff]/40">
                        <span className="text-[10px] font-bold uppercase tracking-wider">
                          {msg.codeBlock.title}
                        </span>
                      </div>
                      <code className="block space-y-1">
                        {msg.codeBlock.lines.map((line, idx) => {
                          let style = "text-[#8aebff]/60";
                          if (line.includes("[WARN]")) style = "text-[#ffb4ab]/80";
                          if (line.includes("[OK]")) style = "text-[#8aebff]/90";
                          return (
                            <span key={idx} className="block">
                              <span className={style}>{line.slice(0, 8)}</span>
                              {line.slice(8)}
                            </span>
                          );
                        })}
                      </code>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          <div ref={chatEndRef}></div>
        </div>

        {/* Chat user input dock */}
        <div className="p-6 pt-0">
          <div className="max-w-4xl mx-auto relative">
            <div className="flex items-center gap-3 bg-[#161e2e]/40 backdrop-blur-2xl rounded-full px-5 py-2.5 border border-[#8aebff]/20 shadow-2xl">
              <button
                className="text-[#8aebff]/40 hover:text-[#8aebff] transition-colors p-2 cursor-pointer"
                title="Attach Protocol File"
              >
                <Plus className="w-5 h-5" />
              </button>
              <div className="h-4 w-[1px] bg-[#8aebff]/20 mx-1"></div>
              <input
                className="flex-1 bg-transparent border-none focus:ring-0 text-sm text-[#dfe2f3] placeholder:text-[#8aebff]/20 px-2 outline-none"
                placeholder="Type a secure command..."
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSend();
                }}
              />
              <div className="flex items-center gap-2">
                <button
                  className="p-2 text-[#8aebff]/40 hover:text-[#8aebff] transition-colors cursor-pointer"
                  title="Voice Command"
                >
                  <Mic className="w-4.5 h-4.5" />
                </button>
                <button
                  className="p-2 text-[#8aebff]/40 hover:text-[#8aebff] transition-colors cursor-pointer"
                  title="Voice Synthesis"
                >
                  <Volume2 className="w-4.5 h-4.5" />
                </button>
                <button
                  onClick={handleSend}
                  className="bg-[#8aebff] text-[#00363e] w-9 h-9 rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-[0_0_15px_rgba(138,235,255,0.4)] ml-1 cursor-pointer"
                  title="Transmit Signal"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex justify-center mt-3">
              <span className="text-[9px] font-mono text-[#8aebff]/30 tracking-[0.25em] uppercase">
                JARVIS v4.0.2 - Secure Enclave Active
              </span>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
}
