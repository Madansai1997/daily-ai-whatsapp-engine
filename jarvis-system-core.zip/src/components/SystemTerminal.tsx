import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Brain, Terminal as TerminalIcon, Volume2, Mic, Activity, ShieldAlert, Sparkles } from "lucide-react";

interface TerminalLine {
  id: string;
  type: "system" | "prompt" | "reply";
  text: string;
  time?: string;
  glow?: boolean;
}

export default function SystemTerminal() {
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([
    { id: "1", type: "system", text: "[SYSTEM] BOOT SEQUENCE INITIATED..." },
    { id: "2", type: "system", text: "[SYSTEM] KERNEL VERSION 14.8.2-STARK" },
    { id: "3", type: "system", text: "[SYSTEM] NEURAL CORE HANDSHAKE... SUCCESS" },
    { id: "4", type: "system", text: "[SYSTEM] IDENTITY VERIFIED: TONY STARK" },
  ]);
  const [commandInput, setCommandInput] = useState("");
  const terminalBodyRef = useRef<HTMLDivElement>(null);

  // Auto-scroll terminal lines
  useEffect(() => {
    terminalBodyRef.current?.scrollTo({
      top: terminalBodyRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [terminalLines]);

  const handleTransmit = () => {
    if (!commandInput.trim()) return;

    const val = commandInput.trim();
    setCommandInput("");

    // Append user command
    const promptId = `prompt-${Date.now()}`;
    const replyId = `reply-${Date.now()}`;

    setTerminalLines((prev) => [
      ...prev,
      { id: promptId, type: "prompt", text: `$ ${val.toUpperCase()}` },
    ]);

    setTimeout(() => {
      let replyText = `[JARVIS]: Directive "${val}" received. Processing at 104.2 Teraflops... Done.`;
      const lower = val.toLowerCase();

      if (lower.includes("status") || lower.includes("diagnostic")) {
        replyText = "[JARVIS]: All core sub-systems reporting nominal operational status. Encryption layers 1-12 secured.";
      } else if (lower.includes("clear")) {
        setTerminalLines([
          { id: `init-${Date.now()}`, type: "system", text: "[LOG BUFFER FLUSHED -- NEW SESSION INITIATED]" }
        ]);
        return;
      } else if (lower.includes("override")) {
        replyText = "[JARVIS WARNING]: Emergency override protocols initiated. Access key requested from Tony Stark. Sector lockdown suspended.";
      } else if (lower.includes("approve") || lower.includes("plan")) {
        replyText = "[JARVIS]: Claude Code Plan approved successfully. Loading workspace modules... Complete.";
      }

      setTerminalLines((prev) => [
        ...prev,
        { id: replyId, type: "reply", text: replyText },
      ]);
    }, 6000e-1);
  };

  const approvePlanDirectly = () => {
    setTerminalLines((prev) => [
      ...prev,
      { id: `act-${Date.now()}`, type: "prompt", text: "$ APPROVE PLAN" },
      { id: `act-reply-${Date.now()}`, type: "reply", text: "[JARVIS]: Sub-routine 0x7E2 validated. Executing alignment tasks." }
    ]);
  };

  const abortPlanDirectly = () => {
    setTerminalLines((prev) => [
      ...prev,
      { id: `act-${Date.now()}`, type: "prompt", text: "$ ABORT PLAN" },
      { id: `act-reply-${Date.now()}`, type: "reply", text: "[JARVIS WARNING]: Plan aborted. Safe state restored." }
    ]);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col h-[calc(100vh-140px)] gap-6"
    >
      {/* Terminal Output logs and Input Prompt */}
      <main className="flex-1 flex flex-col bg-[#0a0e1a]/70 hairline-cyan rounded-lg overflow-hidden relative">
        {/* Terminal tab bar */}
        <div className="h-12 border-b border-[#8aebff]/20 px-6 flex items-center justify-between bg-black/20 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-3">
            <TerminalIcon className="w-4 h-4 text-[#8aebff]" />
            <span className="text-[10px] font-mono text-[#8aebff] tracking-tight font-bold uppercase">
              ROOT@JARVIS: ~ (SESSION: CLAUDE_HUD_X1)
            </span>
          </div>
          <div className="hidden lg:flex gap-6 text-[9px] font-mono text-[#8aebff]/40 uppercase tracking-[0.15em]">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8aebff]/50"></span>
              ENCRYPTION: AES-256-GCM
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8aebff]/50"></span>
              BUFFER: 4096KB
            </span>
            <span className="text-[#8aebff]/70 font-bold border-l border-white/10 pl-6 ml-2">
              STARK_SAT_LINK_7
            </span>
          </div>
        </div>

        {/* Terminal output stream list */}
        <div
          ref={terminalBodyRef}
          className="flex-1 p-8 overflow-y-auto terminal-scroll font-mono text-sm leading-relaxed space-y-6"
        >
          <div className="space-y-1.5 opacity-40 text-xs">
            {terminalLines
              .filter((l) => l.type === "system")
              .slice(0, 4)
              .map((l) => (
                <p key={l.id} className="text-[#8aebff]/70">
                  {l.text}
                </p>
              ))}
            <div className="h-[1px] w-24 bg-[#8aebff]/20 my-4"></div>
          </div>

          <p className="text-[#8aebff] font-bold text-lg glow-cyan tracking-wide">
            J.A.R.V.I.S. online. Command protocol active.
          </p>

          {/* Interactive Claude Code Plan Box */}
          <div className="border border-[#8aebff]/15 border-l-4 border-l-[#8aebff] p-6 bg-[#8aebff]/5 rounded-r-lg backdrop-blur-sm space-y-4 max-w-2xl">
            <div className="flex items-center gap-3">
              <Brain className="w-5 h-5 text-[#8aebff]" />
              <p className="text-[#8aebff] font-bold tracking-widest uppercase text-xs">
                Claude Code Plan
              </p>
            </div>
            <p className="text-[#bbc9cd] leading-relaxed text-sm">
              I'm unable to load the{" "}
              <span className="bg-[#8aebff]/20 px-2 py-0.5 rounded text-[#8aebff] font-bold">
                AskUserQuestion
              </span>{" "}
              tool in this session. Clarification required before proceeding with sub-routine{" "}
              <span className="text-[#8aebff] font-semibold">0x7E2</span>.
            </p>
            <div className="flex gap-4 pt-2">
              <button
                onClick={approvePlanDirectly}
                className="text-[10px] uppercase font-bold tracking-widest text-[#8aebff] border border-[#8aebff]/30 px-5 py-2 rounded bg-[#8aebff]/10 hover:bg-[#8aebff]/20 transition-all cursor-pointer font-mono"
              >
                Approve Plan
              </button>
              <button
                onClick={abortPlanDirectly}
                className="text-[10px] uppercase font-bold tracking-widest text-[#ffb4ab] border border-[#ffb4ab]/30 px-5 py-2 rounded bg-[#ffb4ab]/5 hover:bg-[#ffb4ab]/15 transition-all cursor-pointer font-mono"
              >
                Abort
              </button>
            </div>
          </div>

          {/* Rest of dynamically appended prompt/reply terminal lines */}
          <div className="space-y-4 pt-4 border-t border-white/5">
            {terminalLines
              .filter((l) => l.type !== "system" || terminalLines.indexOf(l) >= 4)
              .map((line) => (
                <div key={line.id}>
                  {line.type === "prompt" ? (
                    <div className="flex gap-3 items-center">
                      <span className="text-[#8aebff] font-black opacity-40 select-none">$</span>
                      <span className="text-[#8aebff] font-semibold tracking-widest">
                        {line.text}
                      </span>
                    </div>
                  ) : (
                    <div className="text-[#8aebff]/70 italic ml-6 border-l-2 border-white/10 pl-4 py-1 leading-relaxed text-xs">
                      {line.text}
                    </div>
                  )}
                </div>
              ))}
          </div>
        </div>

        {/* Terminal shell input prompt */}
        <div className="p-6 bg-black/20 border-t border-[#8aebff]/15 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-4 bg-black/40 border border-[#8aebff]/30 rounded-lg px-4 py-3 glow-cyan-border transition-all focus-within:border-[#8aebff]/60">
            <span className="text-[#8aebff] font-bold text-xl leading-none font-mono select-none">
              &gt;_
            </span>
            <input
              className="flex-1 min-w-0 bg-transparent border-none focus:ring-0 text-[#8aebff] font-mono text-base outline-none p-0"
              placeholder="Enter system command..."
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleTransmit();
              }}
            />
            <div className="flex items-center gap-3 text-[#8aebff]/50 shrink-0">
              <button className="hover:text-[#8aebff] transition-colors p-1 cursor-pointer">
                <Volume2 className="w-5 h-5" />
              </button>
              <button className="hover:text-[#8aebff] transition-colors p-1 cursor-pointer">
                <Mic className="w-5 h-5" />
              </button>
              <button
                onClick={handleTransmit}
                className="bg-[#8aebff]/10 hover:bg-[#8aebff]/25 text-[#8aebff] px-4 py-1.5 rounded text-[11px] font-bold uppercase tracking-[0.2em] transition-all border border-[#8aebff]/30 active:scale-95 cursor-pointer font-mono shrink-0 flex items-center justify-center"
              >
                Transmit
              </button>
            </div>
          </div>
        </div>
      </main>
    </motion.div>
  );
}
